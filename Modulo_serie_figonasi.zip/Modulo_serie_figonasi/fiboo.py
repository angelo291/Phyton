# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:34:17 2020

@author: ANGELO
"""
"""
def fibo(num):
    x=((((1.618034)**num)-((-0.618034)**num))/((5)**(1/2)))
    return x

print(fibo(6))
"""

def fibo(n):
    a,b=0,1
    while a < n:
        print(a, end=" ")
        a,b= b, a+b
    print()
#fib(20)


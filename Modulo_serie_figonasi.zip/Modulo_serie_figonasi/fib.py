# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:48:57 2020

@author: ANGELO
"""

import fiboo
fiboo.fibo(1000)
if __name__=="__main__":
    print("I prefer to be a module")
else:
    print("I like to be a module")